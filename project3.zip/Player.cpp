#include "Player.h"
#include "Board.h"
#include "Game.h"
#include "globals.h"
#include <iostream>
#include <string>

using namespace std;

#include <chrono>



//*********************************************************************
//  AwfulPlayer
//*********************************************************************

class AwfulPlayer : public Player
{
  public:
    AwfulPlayer(string nm, const Game& g);
    virtual bool placeShips(Board& b);
    virtual Point recommendAttack();
    virtual void recordAttackResult(Point p, bool validShot, bool shotHit,
                                                bool shipDestroyed, int shipId);
    virtual void recordAttackByOpponent(Point p);
  private:
    Point m_lastCellAttacked;
};

AwfulPlayer::AwfulPlayer(string nm, const Game& g)
 : Player(nm, g), m_lastCellAttacked(0, 0)
{}

bool AwfulPlayer::placeShips(Board& b)
{
      // Clustering ships is bad strategy
    for (int k = 0; k < game().nShips(); k++)
        if ( ! b.placeShip(Point(k,0), k, HORIZONTAL))
            return false;
    return true;
}

Point AwfulPlayer::recommendAttack()
{
    if (m_lastCellAttacked.c > 0)
        m_lastCellAttacked.c--;
    else
    {
        m_lastCellAttacked.c = game().cols() - 1;
        if (m_lastCellAttacked.r > 0)
            m_lastCellAttacked.r--;
        else
            m_lastCellAttacked.r = game().rows() - 1;
    }
    return m_lastCellAttacked;
}

void AwfulPlayer::recordAttackResult(Point /* p */, bool /* validShot */,
                                     bool /* shotHit */, bool /* shipDestroyed */,
                                     int /* shipId */)
{
      // AwfulPlayer completely ignores the result of any attack
}

void AwfulPlayer::recordAttackByOpponent(Point /* p */)
{
      // AwfulPlayer completely ignores what the opponent does
}

//*********************************************************************
//  HumanPlayer
//*********************************************************************

bool getLineWithTwoIntegers(int& r, int& c)
{
    bool result(cin >> r >> c);
    if (!result)
        cin.clear();  // clear error state so can do more input operations
    cin.ignore(10000, '\n');
    return result;
}

// TODO:  You need to replace this with a real class declaration and
//        implementation.
//typedef AwfulPlayer HumanPlayer;

class HumanPlayer : public Player
{
public:
    HumanPlayer(string nm, const Game&g);
    virtual bool isHuman() const;
    virtual bool placeShips(Board& b);
    virtual Point recommendAttack();
    virtual void recordAttackResult(Point p, bool validShot, bool shotHit,
                                    bool shipDestroyed, int shipId);
    virtual void recordAttackByOpponent(Point p);
private:
    vector<Point> chosen;
};

HumanPlayer::HumanPlayer(string nm, const Game&g): Player(nm, g)
{}

bool HumanPlayer::isHuman() const{
    return true;
}

bool HumanPlayer::placeShips(Board& b){
    //if the game parameters are such that there is no configuration of ships that will fit, addShip will always return false and no ship will be added to the game
    if(game().nShips()==0){
        return true;
    }
    int totalOfLengths = 0;
    for (int s = 0; s < game().nShips(); s++)
    {
        totalOfLengths += game().shipLength(s);
    }
    if (totalOfLengths > game().rows() * game().cols())
    {
        return false;
    }

    cout<< name() <<" must place " << game().nShips() << " ships." << endl;
    b.display(false);
    for(int i=0; i<game().nShips(); i++){
        string dir;
        cout<<"Enter h or v for direction of " <<  game().shipName(i) << " (length " << game().shipLength(i) << "): ";
        getline(cin,dir);
        
        while(dir[0]!= 'h' && dir[0]!= 'v'){
            cout<< "Direction must be h or v." <<endl;
            cout<<"Enter h or v for direction of " <<  game().shipName(i) << " (length " << game().shipLength(i) << "): ";
            getline(cin,dir);
        }
        
        Direction d;
        if(dir[0] == 'h'){
            d = HORIZONTAL;
        }
        else{
            d = VERTICAL;
        }
        
        //check if it's possible to place that ship in that direction
        if(game().shipLength(i)>game().rows()&&game().shipLength(i)>game().cols()){
            return false;
        }
        
        while((d==HORIZONTAL && game().shipLength(i)>game().rows()) || (d==VERTICAL && game().shipLength(i)>game().cols())){
            cout<< "The ship cannot be placed in this direction." <<endl;
            cout<<"Enter h or v for direction of " <<  game().shipName(i) << " (length " << game().shipLength(i) << "): ";
            getline(cin,dir);
            while(dir[0]!= 'h' && dir[0]!= 'v'){
                cout<< "Direction must be h or v." <<endl;
                cout<<"Enter h or v for direction of " <<  game().shipName(i) << " (length " << game().shipLength(i) << "): ";
                getline(cin,dir);
            }
            if(dir[0] == 'h'){
                d = HORIZONTAL;
            }
            else{
                d = VERTICAL;
            }
        }
        
        string leftOrTop = "";
        if(d==HORIZONTAL){
            leftOrTop = "leftmost";
        }
        else{
            leftOrTop = "topmost";
        }
        //get the row and column
        int r,c;
        cout<<"Enter row and column of "<< leftOrTop <<" cell (e.g., 3 5): ";
        while(getLineWithTwoIntegers(r, c) == false){
            cout<< "You must enter two integers." << endl;
            cout<<"Enter row and column of "<< leftOrTop <<" cell (e.g., 3 5): ";
        }
        
        Point p(r,c);
        
        while(b.placeShip(p, i, d) == false){
            //check if it's possible to place another ship
            
            cout<< "The ship can not be placed there." << endl;
            cout<< "Enter row and column of "<< leftOrTop <<" cell (e.g., 3 5): ";
            while(getLineWithTwoIntegers(r, c) == false){
                cout<< "You must enter two integers." << endl;
                cout<<"Enter row and column of "<< leftOrTop <<" cell (e.g., 3 5): ";
            }
            p.r = r;
            p.c = c;
        }
        
        //b.placeShip will have returned true
        if(i!=game().nShips()-1){
            b.display(false);
        }
        
    }
    
    return true;
    
}

Point HumanPlayer::recommendAttack(){
    int r,c;
    cout<< "Enter the row and column to attack (e.g., 3 5): ";
    while(getLineWithTwoIntegers(r, c) == false){
        cout<< "You must enter two integers." << endl;
        cout<<"Enter the row and column to attack (e.g., 3 5): ";
    }
    Point p(r,c);
    return p;
}

void HumanPlayer::recordAttackResult(Point p, bool validShot, bool shotHit,
                                     bool shipDestroyed, int shipId){
    
}

void HumanPlayer::recordAttackByOpponent(Point p){
    
}

//*********************************************************************
//  MediocrePlayer
//*********************************************************************

// TODO:  You need to replace this with a real class declaration and
//        implementation.
bool putship(const Game& g, Board& b, int ship){ //auxiliary recursive function
    //base class: size of board is smaller than the boat
    if(ship>=g.nShips())
    {
        return true;
    }
    
    for(int r=0; r<g.rows();r++){
        for(int c=0; c<g.cols();c++){
            if(b.placeShip(Point(r,c), ship, HORIZONTAL))
            {
                if(putship(g, b, ship+1))
                {
                    return true;
                }
            }
            if(b.placeShip(Point(r,c), ship, VERTICAL))
            {
                if(putship(g, b, ship+1))
                {
                    return true;
                }
            }
        }
    }
    //the ship could not be placed
    if(ship==0){
        return false;
    }
    //backtrack
    for(int r=0; r<g.rows();r++){
        for(int c=0; c<g.cols();c++){
            b.unplaceShip(Point(r,c), ship-1, HORIZONTAL);
            b.unplaceShip(Point(r,c), ship-1, VERTICAL);
        }
    }
    return false;
}

class MediocrePlayer : public Player{
public:
    MediocrePlayer(string nm, const Game&g);
    virtual bool placeShips(Board& b);
    virtual Point recommendAttack();
    virtual void recordAttackResult(Point p, bool validShot, bool shotHit,
                                        bool shipDestroyed, int shipId);
    virtual void recordAttackByOpponent(Point p);
    bool allChosen(); //see if all the spots in the cross have been chosen
    
private:
    vector<Point> chosen;
    Point target;
    int state;
    
};

MediocrePlayer::MediocrePlayer(string nm, const Game&g): Player(nm, g),state(1)
{}


bool MediocrePlayer::placeShips(Board& b){
    //if the game parameters are such that there is no configuration of ships that will fit, addShip will always return false and no ship will be added to the game
    if(game().nShips()==0){
        return true;
    }
    for(int i=0; i<50; i++){
        b.block();
        //recursive algorithm
        if(putship(game(),b,0)){
            b.unblock();
            return true;
        }
        b.unblock();
    }

    return false;
}
bool MediocrePlayer::allChosen(){ //check if all the points in the cross have been chosen already
    for(int index =1; index<=4; index++){
        Point a(target.r - index, target.c);
        if(game().isValid(a)){
            bool alreadyChosen = false;
            for(int i=0; i<chosen.size();i++){
                if(chosen[i].r == a.r && chosen[i].c == a.c){
                    alreadyChosen = true;
                }
            }
            if(alreadyChosen == false){
                return false;
            }
        }
        else{
            break;
        }
    }
    for(int index =1; index<=4; index++){
        Point b(target.r + index, target.c);
        if(game().isValid(b)){
            bool alreadyChosen = false;
            for(int i=0; i<chosen.size();i++){
                if(chosen[i].r == b.r && chosen[i].c == b.c){
                    alreadyChosen = true;
                }
            }
            if(alreadyChosen == false){
                return false;
            }
        }
        else{
            break;
        }
    }
    for(int index =1; index<=4; index++){
        Point c(target.r,target.c-index);
        if(game().isValid(c)){
            bool alreadyChosen = false;
            for(int i=0; i<chosen.size();i++){
                if(chosen[i].r == c.r && chosen[i].c == c.c){
                    alreadyChosen = true;
                }
            }
            if(alreadyChosen == false){
                return false;
            }
        }
        else{
            break;
        }
    }
    for(int index =1; index<=4; index++){
        Point d(target.r,target.c+index);
        if(game().isValid(d)){
            bool alreadyChosen = false;
            for(int i=0; i<chosen.size();i++){
                if(chosen[i].r == d.r && chosen[i].c == d.c){
                    alreadyChosen = true;
                }
            }
            if(alreadyChosen == false){
                return false;
            }
        }
        else{
            break;
        }
    }
    
    return true;
}


Point MediocrePlayer::recommendAttack(){
    int r =0, c=0;
    Point p;
    bool alreadyChosen = true;
//    If the game has ships of length 6 or more, it's possible that every position no more
//    than 4 steps from (r,c) has been previously chosen. In that case, switch to state 1
//    and use its selection algorithm.
    if(state==1||(state==2 && allChosen())){
        state=1;
        alreadyChosen = true;
        while(alreadyChosen == true){
            alreadyChosen = false;
            r = randInt(game().rows());
            c = randInt(game().cols());
            for(int i=0; i<chosen.size();i++){
                if(chosen[i].r == r && chosen[i].c == c){
                    alreadyChosen = true;
                }
            }
        }
        
        p = Point(r,c);
    }
    
    else if(state==2){
        p = Point(-1,-1);
        while(alreadyChosen == true){
            int move = randInt(4); //spots to move
            if (randInt(2)==0){ //vertical
                if(randInt(2)==0){//up
                    p = Point(target.r - move - 1, target.c);
                }
                else{//down
                    p = Point(target.r + move + 1, target.c);
                    
                }
            }
            else{//horizontal
                if(randInt(2)==0){//left
                    p = Point(target.r, target.c - move - 1);
                }
                else{
                    p = Point(target.r, target.c + move + 1);
                }
                
            }
            
            if(game().isValid(p) == false){
                continue; //if it is an invalid point, go back to the top of the while loop
            }
        
            alreadyChosen = false;
            for(int i=0; i<chosen.size();i++){
                if(chosen[i].r == p.r && chosen[i].c == p.c){
                    alreadyChosen = true;
                }
            }
        }
    }
    
    chosen.push_back(p);
    return p;
}


void MediocrePlayer::recordAttackResult(Point p, bool validShot, bool shotHit,
                                        bool shipDestroyed, int shipId){
    
    if(state==1){
        if(validShot && shotHit && !shipDestroyed){
            state = 2;
            target = p;
        }
    }
    else if(state==2){
        if(validShot && shotHit && shipDestroyed){
            //account for case where another ship is destroyed
            state = 1;
        }
    }
    
}
           

void MediocrePlayer::recordAttackByOpponent(Point p){
}
// Remember that Mediocre::placeShips(Board& b) must start by calling
// b.block(), and must call b.unblock() just before returning.

//*********************************************************************
//  GoodPlayer
//*********************************************************************

// TODO:  You need to replace this with a real class declaration and
//        implementation.
class GoodPlayer : public Player{
public:
    GoodPlayer(string nm, const Game&g);
    virtual bool placeShips(Board& b);
    virtual Point recommendAttack();
    virtual void recordAttackResult(Point p, bool validShot, bool shotHit,
                                        bool shipDestroyed, int shipId);
    virtual void recordAttackByOpponent(Point p);
    bool putship(Board& b, int ship);
    bool allChosen(int x); //see if all the spots in cross of size x have been chosen
    bool allChosenLine(); //see if all spots in line have been chosen
    Point switchToCross(int x); //switch to cross of size four
    
private:
    vector<Point> chosen;
    Point target;
    Point newtarget;
    int state;
    Direction attackDir;
    vector<Point> checkerboard;
    
};
GoodPlayer::GoodPlayer(string nm, const Game&g): Player(nm,g){
    state = 1;
    attackDir = HORIZONTAL;
    // create a checkerboard
       for (int r = 0; r < game().rows(); r++) {
           for (int c = 0; c < game().cols(); c++) {
               
               // odd row even col
               if (r % 2 != 0 && c % 2 == 0) {
                   checkerboard.push_back(Point(r,c));
                }
               // even row odd col
               if (r % 2 == 0 && c % 2 != 0) {
                   checkerboard.push_back(Point(r,c));
                }
           }
           
       }
}
bool GoodPlayer::putship(Board& b, int ship){ //auxiliary recursive function
    //base class: size of board is smaller than the boat
    if(ship>=game().nShips())
    {
        return true;
    }
    
    for(int r=0; r<game().rows();r++){
        for(int c=0; c<game().cols();c++){
            if(b.placeShip(Point(r,c), ship, HORIZONTAL))
            {
                if(putship(b, ship+1))
                {
                    return true;
                }
            }
            if(b.placeShip(Point(r,c), ship, VERTICAL))
            {
                if(putship(b, ship+1))
                {
                    return true;
                }
            }
        }
    }
    if(ship==0){
        return false;
    }
    for(int r=0; r<game().rows();r++){
        for(int c=0; c<game().cols();c++){
            b.unplaceShip(Point(r,c), ship-1, HORIZONTAL);
            b.unplaceShip(Point(r,c), ship-1, VERTICAL);
        }
    }
    return false;
}

bool GoodPlayer::placeShips(Board& b){
    if(game().nShips()==0){
        return true;
    }
    if(game().nShips()<=5 && game().rows()>=10 && game().cols()>=10){
        bool possible = true;
        for(int i=0; i<4;i++){
            if(i==game().nShips()){
                break;
            }
            int r=-1,c=-1;
            if(randInt(2)==0){
                int counter = 0;
                while(!b.placeShip(Point(r,c), i, HORIZONTAL) && counter!=50){
                    if(i==0){
                        r = randInt(3);
                       c = randInt(3);
                    }
                    if(i==1){
                        r = randInt(3);
                        c = game().cols()/2+(randInt(game().cols()/2));
                    }
                    if(i==2){
                        r = game().rows()/2 + (randInt(game().rows()/2));
                        c = randInt(3);
                    }
                    if(i==3){
                        r = game().rows()/2 + (randInt(game().rows()/2));
                        c = game().cols()/2 +(randInt(game().cols()/2));
                    }
                    counter++;
                    if(counter==50){
                        possible = false;
                    }
                }
            }
            else{
                int counter = 0;
                while(!b.placeShip(Point(r,c), i, VERTICAL) && counter!=50){
                    if(i==0){
                        r = randInt(3);
                        c = randInt(3);
                    }
                    if(i==1){
                        r = randInt(3);
                        c = randInt(3)+ (game().cols()/2);
                    }
                    if(i==2){
                        r = randInt(3) + (game().rows()/2);
                        c = randInt(3);
                    }
                    if(i==3){
                        r = randInt(3) + (game().rows()/2);
                        c = randInt(3)+ (game().cols()/2);
                    }
                    counter++;
                    if(counter==50){
                        possible = false;
                    }
                }
            }
          

        }
        if(game().nShips()<=4){
            return true;
        }
//        for(int i=4;i<game().nShips();i++){
            int r = randInt(game().rows());
            int c=randInt(game().cols());
            if(randInt(2)==0){
                int counter = 0;
                while(!b.placeShip(Point(r,c), 4, HORIZONTAL)&&counter!=50){
                    r= randInt(game().rows());
                    c=randInt(game().cols());
                    counter++;
                    if(counter==50){
                        possible = false;
                    }
                }
            }
            else{
                int counter = 0;
                while(!b.placeShip(Point(r,c), 4, VERTICAL) && counter!=50){
                    r= randInt(game().rows());
                    c=randInt(game().cols());
                    counter++;
                    if(counter==50){
                        possible = false;
                    }
                }
            }
        //}
        
        if(possible){
            return true;
        }
    }
    
    //if it was not possible or the game parameters didn't match standard/similar to standard:
        for(int i=0; i<game().nShips();i++){
            for(int r=0; r<game().rows();r++){
                for(int c=0; c<game().cols();c++){
                    b.unplaceShip(Point(r,c), i, HORIZONTAL);
                    b.unplaceShip(Point(r,c), i, VERTICAL);
                }
            }
        }
        for(int i=0; i<50; i++){
            b.block();
            //recursive algorithm
            if(putship(b,0)){
                b.unblock();
                return true;
            }
            b.unblock();
        }
        return false;
}
bool GoodPlayer::allChosenLine(){
    //for(int i=1; i<=x;i++)
    if(attackDir == VERTICAL){
        Point a(newtarget.r - 1, newtarget.c);
        if(game().isValid(a)){
            bool alreadyChosen = false;
            for(int i=0; i<chosen.size();i++){
                if(chosen[i].r == a.r && chosen[i].c == a.c){
                    alreadyChosen = true;
                }
            }
            if(alreadyChosen == false){
                return false;
            }
        }
        Point b(newtarget.r + 1, newtarget.c);
        if(game().isValid(b)){
            bool alreadyChosen = false;
            for(int i=0; i<chosen.size();i++){
                if(chosen[i].r == b.r && chosen[i].c == b.c){
                    alreadyChosen = true;
                }
            }
            if(alreadyChosen == false){
                return false;
            }
        }
        return true;
    }
    
    else{
        Point c(newtarget.r,newtarget.c-1);
        if(game().isValid(c)){
            bool alreadyChosen = false;
            for(int i=0; i<chosen.size();i++){
                if(chosen[i].r == c.r && chosen[i].c == c.c){
                    alreadyChosen = true;
                }
            }
            if(alreadyChosen == false){
                return false;
            }
        }
        Point d(newtarget.r,newtarget.c+1);
        if(game().isValid(d)){
            bool alreadyChosen = false;
            for(int i=0; i<chosen.size();i++){
                if(chosen[i].r == d.r && chosen[i].c == d.c){
                    alreadyChosen = true;
                }
            }
            if(alreadyChosen == false){
                return false;
            }
        }
        return true;
    }
    
}

bool GoodPlayer::allChosen(int x){
    for(int index =1; index<=x; index++){
        Point a(target.r - index, target.c);
        if(game().isValid(a)){
            bool alreadyChosen = false;
            for(int i=0; i<chosen.size();i++){
                if(chosen[i].r == a.r && chosen[i].c == a.c){
                    alreadyChosen = true;
                }
            }
            if(alreadyChosen == false){
                return false;
            }
        }
        else{
            break;
        }
    }
    for(int index =1; index<=x; index++){
        Point b(target.r + index, target.c);
        if(game().isValid(b)){
            bool alreadyChosen = false;
            for(int i=0; i<chosen.size();i++){
                if(chosen[i].r == b.r && chosen[i].c == b.c){
                    alreadyChosen = true;
                }
            }
            if(alreadyChosen == false){
                return false;
            }
        }
        else{
            break;
        }
    }
    for(int index =1; index<=x; index++){
        Point c(target.r,target.c-index);
        if(game().isValid(c)){
            bool alreadyChosen = false;
            for(int i=0; i<chosen.size();i++){
                if(chosen[i].r == c.r && chosen[i].c == c.c){
                    alreadyChosen = true;
                }
            }
            if(alreadyChosen == false){
                return false;
            }
        }
        else{
            break;
        }
    }
    for(int index =1; index<=x; index++){
        Point d(target.r,target.c+index);
        if(game().isValid(d)){
            bool alreadyChosen = false;
            for(int i=0; i<chosen.size();i++){
                if(chosen[i].r == d.r && chosen[i].c == d.c){
                    alreadyChosen = true;
                }
            }
            if(alreadyChosen == false){
                return false;
            }
        }
        else{
            break;
        }
    }
    
    return true;
}
Point GoodPlayer::switchToCross(int x){
    Point p(-1,-1);
    bool alreadyChosen = true;
    while(alreadyChosen == true){
        int move = randInt(x); //spots to move
        if (randInt(2)==0){ //vertical
            if(randInt(2)==0){//up
                p = Point(target.r - move - 1, target.c);
            }
            else{//down
                p = Point(target.r + move + 1, target.c);
                
            }
        }
        else{//horizontal
            if(randInt(2)==0){//left
                p = Point(target.r, target.c - move - 1);
            }
            else{
                p = Point(target.r, target.c + move + 1);
            }
            
        }
        
        if(game().isValid(p) == false){
            continue; //if it is an invalid point, go back to the top of the while loop
        }
    
        alreadyChosen = false;
        for(int i=0; i<chosen.size();i++){
            if(chosen[i].r == p.r && chosen[i].c == p.c){
                alreadyChosen = true;
            }
        }
    }
    chosen.push_back(p);
    return p;
}

Point GoodPlayer::recommendAttack(){
    
    int r =0, c=0;
    Point p;
    bool alreadyChosen = true;
//    If the game has ships of length 6 or more, it's possible that every position no more
//    than 4 steps from (r,c) has been previously chosen. In that case, switch to state 1
//    and use its selection algorithm.

    if(state==1||(state==2&&allChosen(4))||(state==3&&allChosen(4))){
        state=1;
        if(checkerboard.empty()){
            alreadyChosen = true;
            while(alreadyChosen){
                alreadyChosen = false;
                r = randInt(game().rows());
                c = randInt(game().cols());
                for(int i=0; i<chosen.size();i++){
                    if(chosen[i].r == r && chosen[i].c == c){
                        alreadyChosen = true;
                    }
                }
            }
            p = Point(r,c);
        }
        else{
            while(alreadyChosen){
                p = checkerboard.front();
                alreadyChosen = false;
                for(int i=0; i<chosen.size();i++){
                    if(chosen[i].r == p.r && chosen[i].c == p.c){
                        alreadyChosen = true;
                    }
                }
                
                if(alreadyChosen){
                    checkerboard.erase(checkerboard.begin());
                }
                else{
                    chosen.push_back(p);
                    checkerboard.erase(checkerboard.begin());
                    return p;
                }
               
            }
        }
       
        
    }
    
    else if(state==2){
        if(allChosen(3)){//if everything in the 3 cross has been chosen, switch to 4 cross
            return switchToCross(4); //it adds it to the chosen vector
        }
        else if(allChosen(2)){
            return switchToCross(3);
        }
        else if(allChosen(1)){
            return switchToCross(2);
        }
        p = Point(-1,-1);
        while(alreadyChosen == true){
    
            if (randInt(2)==0){ //vertical
                if(randInt(2)==0){//up
                    p = Point(target.r - 1, target.c);
                }
                else{//down
                    p = Point(target.r + 1, target.c);
                    
                }
            }
            else{//horizontal
                if(randInt(2)==0){//left
                    p = Point(target.r, target.c - 1);
                }
                else{ //right
                    p = Point(target.r, target.c + 1);
                }
                
            }
            
            if(game().isValid(p) == false){
                continue; //if it is an invalid point, go back to the top of the while loop
            }
        
            alreadyChosen = false;
            for(int i=0; i<chosen.size();i++){
                if(chosen[i].r == p.r && chosen[i].c == p.c){
                    alreadyChosen = true;
                }
            }
        }
    }
    
    else if(state==3){//if all the points in that line have been chosen, go back to the original target (start from newtarget)
        //if all been chosen from original target, then change directions
        //if you miss go back to original target
        if(allChosenLine()){
            //check the points one more spot over
            newtarget = Point(target.r,target.c);//all the points next to newtarget (in the line) have been chosen, return to the original target
        }
        if(allChosenLine()){
            if(attackDir==VERTICAL){
                attackDir = HORIZONTAL;
            }
            else{
                attackDir = VERTICAL;
            }
        }
        if(allChosenLine()){
            //that means all of the points one spot away from target and one target have been chosen, so pick a point in the cross (like you did for mediocre)
            if(!allChosen(2)){
                return switchToCross(2);
            }
            else if(!allChosen(3)){
                return switchToCross(3);
            }
            else if(!allChosen(4)){
                return switchToCross(4);
            }
        }
        else{
            p = Point(-1,-1);
            while(alreadyChosen == true){
                if (attackDir == VERTICAL){
                    if(randInt(2)==0){//up
                        p = Point(newtarget.r - 1, newtarget.c);
                    }
                    else{//down
                        p = Point(newtarget.r + 1, newtarget.c);
                        
                    }
                }
                else{//horizontal
                    if(randInt(2)==0){//left
                        p = Point(newtarget.r, newtarget.c - 1);
                    }
                    else{
                        p = Point(newtarget.r, newtarget.c + 1);
                    }
                    
                }
                
                if(game().isValid(p) == false){
                    continue; //if it is an invalid point, go back to the top of the while loop
                }
            
                alreadyChosen = false;
                for(int i=0; i<chosen.size();i++){
                    if(chosen[i].r == p.r && chosen[i].c == p.c){
                        alreadyChosen = true;
                    }
                }
            }
        }
    }
//    cout<<"RECOMMEND" << p.r <<"," <<p.c<<endl;
//    cout<<"STATE" << state<<endl;
    chosen.push_back(p);
    return p;
}

void GoodPlayer::recordAttackResult(Point p, bool validShot, bool shotHit,
                                    bool shipDestroyed, int shipId){
    if(state==1){
        if(validShot && shotHit && !shipDestroyed){
            state = 2;
            target = p;
            newtarget = p;
        }
    }
    else if(state==2){
        if(validShot && shotHit && !shipDestroyed){
            state = 3;
            newtarget = p;
            if(target.r-1==p.r || target.r+1 == p.r){
                attackDir = VERTICAL;
            }
            else{
                attackDir = HORIZONTAL;
            }
        }
        else if(validShot && shotHit && shipDestroyed){
            state = 1;

        }
    }
    else if(state == 3){
        if(validShot && shotHit && shipDestroyed){
            state = 1;

        }
        if(validShot && shotHit && !shipDestroyed){
            newtarget = p;
        }
    }

}
void GoodPlayer::recordAttackByOpponent(Point p){
    
}


//*********************************************************************
//  createPlayer
//*********************************************************************

Player* createPlayer(string type, string nm, const Game& g)
{
    static string types[] = {
        "human", "awful", "mediocre", "good"
    };
    
    int pos;
    for (pos = 0; pos != sizeof(types)/sizeof(types[0])  &&
                                                     type != types[pos]; pos++)
        ;
    switch (pos)
    {
      case 0:  return new HumanPlayer(nm, g);
      case 1:  return new AwfulPlayer(nm, g);
      case 2:  return new MediocrePlayer(nm, g);
      case 3:  return new GoodPlayer(nm, g);
      default: return nullptr;
    }
}
