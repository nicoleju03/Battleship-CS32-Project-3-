#include "Game.h"
#include "Player.h"
#include "Board.h" //i added
#include <iostream>
#include <string>
#include <cassert>

//========================================================================
// Timer t;                 // create a timer and start it
// t.start();               // start the timer
// double d = t.elapsed();  // milliseconds since timer was last started
//========================================================================

#include <chrono>

class Timer
{
  public:
    Timer()
    {
        start();
    }
    void start()
    {
        m_time = std::chrono::high_resolution_clock::now();
    }
    double elapsed() const
    {
        std::chrono::duration<double,std::milli> diff =
                          std::chrono::high_resolution_clock::now() - m_time;
        return diff.count();
    }
  private:
    std::chrono::high_resolution_clock::time_point m_time;
};


using namespace std;

bool addStandardShips(Game& g)
{
    return g.addShip(5, 'A', "aircraft carrier")  &&
           g.addShip(4, 'B', "battleship")  &&
           g.addShip(3, 'D', "destroyer")  &&
           g.addShip(3, 'S', "submarine")  &&
           g.addShip(2, 'P', "patrol boat");
}



int main()
{
    //test row and col
//    Game g1(5,6);
//    assert(g1.rows()==5 && g1.cols()==6);
//    g1.addShip(1,'A', "a");
//    g1.addShip(5,'B',"b");
    
    
    Game g(5,5);
    g.addShip(3, 'A', "a");
    g.addShip(4, 'B', "b");
   // g.addShip(5,'C',"c");
    //addStandardShips(g);
    Board b1(g);
    
    //test board
//    b1.display(false);
//    b1.block();
//    b1.display(false);
//    b1.unblock();
//    b1.display(false);
//    assert(b1.placeShip(Point(1,1), 0, HORIZONTAL)==true);
//    assert(b1.placeShip(Point(1,1), 2, VERTICAL) == false);
//    assert(b1.placeShip(Point(4,5),0,VERTICAL) == false);
//    assert(b1.placeShip(Point(4,5), 2, VERTICAL) == true);
//    assert(b1.placeShip(Point(10,1),3,HORIZONTAL) == false);
//    //assert(b1.unplaceShip(Point(4,5),2,VERTICAL) == true);
//    bool shotHit,shipDestroyed;
//    int shipId;
//    assert(b1.attack(Point(5,5), shotHit, shipDestroyed, shipId) && shotHit == true && shipDestroyed == false);
//    assert(b1.unplaceShip(Point(4,5),2,VERTICAL) == false);
//    b1.display(false);
//
//    assert(b1.attack(Point(-1,7),shotHit,shipDestroyed,shipId) == false);
//    assert(b1.attack(Point(4,5),shotHit,shipDestroyed,shipId) && shotHit && !shipDestroyed);
//    assert(b1.attack(Point(4,5),shotHit,shipDestroyed,shipId)==false);
//    assert(b1.attack(Point(6,5),shotHit,shipDestroyed,shipId) && shotHit && shipDestroyed && shipId==2);
//    b1.display(false);
    
//    Player* human = createPlayer("human","nicole",g);
//    assert(human->isHuman());
//    human->placeShips(b1);
//    b1.display(false);
    Timer timer;
    Player* p1 = createPlayer("good", "one", g);
  //  timer.start();
    p1->placeShips(b1);
    
   //cout << timer.elapsed();
    b1.display(false);
    
    Board b2(g);
    Player* p2 = createPlayer("good", "two",g);
    p2->placeShips(b2);
    b2.display(false);
    
    //g.play(p1,p2);
    
    bool shotHit, shipDestroyed;
    int shipId = 0;
    timer.start();
    Point rec1 = p1->recommendAttack();
    bool validAttack = b2.attack(rec1, shotHit, shipDestroyed, shipId);
    p1->recordAttackResult(rec1, validAttack, shotHit, shipDestroyed, shipId);
    cout << timer.elapsed()<<endl;
    b2.display(false);

//
//    g.play(p1,p2,false);
    
//    Point point1 = p1->recommendAttack(); //recommend attack is wrong!
//    cout<<point1.r<<" " << point1.c << endl;
    //stage 2 doesn't work, doesn't shoot in the cross
    
    
//    b.block();
//    b.display(false);
//    b.unblock();
//    b.display(false);
//
//
//    g.addShip(4, 'A', "zero");
//    g.addShip(3, 'B', "one");
//    g.addShip(5, 'C', "two");
//    Point p(1,2);
//
//    //test invalid id
//    assert(b.placeShip(p,3,VERTICAL)==false);
//
//    //test outside board;
//    p.r = -1;
//    assert(b.placeShip(p,1,HORIZONTAL) ==false);
//    p.c = 10;
//    assert(b.placeShip(p,1,HORIZONTAL) ==false);
//    p.r=6;
//    p.c = 1;
//    assert(b.placeShip(p,2,VERTICAL) == false);
//    p.c = 8;
//    assert(b.placeShip(p,1,HORIZONTAL) == false);
//
//    //test overlapping ships
//    p.r = 2;
//    p.c = 2;
//    b.placeShip(p,2,HORIZONTAL);
//    b.display(false);
//    p.r = 1;
//    p.c = 3;
//    assert(b.placeShip(p,0,VERTICAL) ==false);
//
//    //test repeat id
//    p.r=4;
//    assert(b.placeShip(p,2,HORIZONTAL) == false);
//
//    //test unplace ship
//    assert(b.unplaceShip(p, 2, HORIZONTAL) == false);
//    b.display(false);
//
//    p.r = 2;
//    p.c = 2;
//    assert(b.unplaceShip(p, 3, HORIZONTAL) == false);
//    assert(b.unplaceShip(p, 2, HORIZONTAL) == true);
//    b.display(false);
//
//
    
    const int NTRIALS = 100;

    cout << "Select one of these choices for an example of the game:" << endl;
    cout << "  1.  A mini-game between two mediocre players" << endl;
    cout << "  2.  A mediocre player against a human player" << endl;
    cout << "  3.  A " << NTRIALS
         << "-game match between a mediocre and an awful player, with no pauses"
         << endl;
    cout << "Enter your choice: ";
    string line;
    getline(cin,line);
    if (line.empty())
    {
        cout << "You did not enter a choice" << endl;
    }
    else if (line[0] == '1')
    {
        Game g(2, 3);
        g.addShip(2, 'R', "rowboat");
        Player* p1 = createPlayer("mediocre", "Popeye", g);
        Player* p2 = createPlayer("mediocre", "Bluto", g);
        cout << "This mini-game has one ship, a 2-segment rowboat." << endl;
        g.play(p1, p2);
        delete p1;
        delete p2;
    }
    else if (line[0] == '2')
    {
        Game g(10, 10);
        addStandardShips(g);
        Player* p1 = createPlayer("mediocre", "Mediocre Midori", g);
        Player* p2 = createPlayer("human", "Shuman the Human", g);
        g.play(p1, p2);
        delete p1;
        delete p2;
    }
    else if (line[0] == '3')
    {
        int nMediocreWins = 0;

        for (int k = 1; k <= NTRIALS; k++)
        {
            cout << "============================= Game " << k
                 << " =============================" << endl;
            Game g(10, 10);
//            g.addShip(3, 'A', "a");
//            g.addShip(4, 'B', "b");
            addStandardShips(g);
            Player* p1 = createPlayer("good", "good Audrey", g);
            Player* p2 = createPlayer("mediocre", "Mediocre Mimi", g);
            Player* winner = (k % 2 == 1 ?
                                g.play(p1, p2, false) : g.play(p2, p1, false));
            if (winner == p2)
                nMediocreWins++;
            delete p1;
            delete p2;
        }
        cout << "The mediocre player won " << nMediocreWins << " out of "
             << NTRIALS << " games." << endl;
          // We'd expect a mediocre player to win most of the games against
          // an awful player.  Similarly, a good player should outperform
          // a mediocre player.
    }
    else
    {
       cout << "That's not one of the choices." << endl;
    }
}

