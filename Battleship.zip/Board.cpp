#include "Board.h"
#include "Game.h"
#include "globals.h"
#include <iostream>
#include <vector>
using namespace std;

class BoardImpl
{
  public:
    BoardImpl(const Game& g);
    void clear();
    void block();
    void unblock();
    bool placeShip(Point topOrLeft, int shipId, Direction dir);
    bool unplaceShip(Point topOrLeft, int shipId, Direction dir);
    void display(bool shotsOnly) const;
    bool attack(Point p, bool& shotHit, bool& shipDestroyed, int& shipId);
    bool allShipsDestroyed() const;

  private:
      // TODO:  Decide what private members you need.  Here's one that's likely
      //        to be useful:
    const Game& m_game;
    char m_grid[MAXROWS][MAXCOLS]; //filled with ., X, o, and ship symbols
    vector<int> m_shipIds;
};

BoardImpl::BoardImpl(const Game& g)
 : m_game(g)
{
    for (int r=0 ; r < g.rows() ; r++){
        for(int c=0; c < g.cols(); c++){
            m_grid[r][c] = '.';
        }
    }
    m_shipIds = {};
    // This compiles, but may not be correct
}

void BoardImpl::clear()
{
    for (int r=0 ; r < m_game.rows() ; r++){
        for(int c=0; c < m_game.cols(); c++){
            m_grid[r][c] = '.';
        }
    }
    // This compiles, but may not be correct
}

void BoardImpl::block()
{ //maybe change
    int numBlocked = 0;
    int half = (m_game.rows()*m_game.cols())/2; //find number that needs to be blocked
      // Block cells with 50% probability
    while (numBlocked < half){
        int r = randInt(m_game.rows());
        int c = randInt(m_game.cols());
        if(m_grid[r][c]=='-'){
            continue;
        }
        m_grid[r][c] = '-';
        numBlocked++;
        
    }
 
}

void BoardImpl::unblock()
{
    for (int r = 0; r < m_game.rows(); r++)
        for (int c = 0; c < m_game.cols(); c++)
        {
            // TODO:  Replace this with code to unblock cell (r,c) if blocked
            if (m_grid[r][c] == '-'){
                m_grid[r][c] = '.';
            }
        }
}

bool BoardImpl::placeShip(Point topOrLeft, int shipId, Direction dir)
{
    //check if shipId is invalid
    if(shipId<0 || shipId > m_game.nShips()-1){
        return false;
    }
       
    int length = m_game.shipLength(shipId);
    
    if (dir == HORIZONTAL){
        //check if it is in right/left bounds
        Point right(topOrLeft.r, (topOrLeft.c + length - 1));
        
        
        if(!m_game.isValid(topOrLeft) || !m_game.isValid(right)){
            return false;
        }
        
        //check if overlapping a ship or blocked position
        for(int i=0; i<length; i++){
            if(m_grid[topOrLeft.r][topOrLeft.c+i] != '.'){
                return false;
            }
        }
    }
    
    if (dir == VERTICAL){
        //check if in top/bottom bounds
        Point bottom((topOrLeft.r + length - 1), topOrLeft.c);
        
        
        if(!m_game.isValid(topOrLeft) || !m_game.isValid(bottom)){
            return false;
        }
        
        //check if overlapping a ship or blocked position
        for(int i=0; i<length; i++){
            if(m_grid[topOrLeft.r+i][topOrLeft.c] != '.'){
                return false;
            }
        }
    }
    
    //check if the ship with this id has already been placed
    for(int i=0; i<m_shipIds.size(); i++){
        if(m_shipIds[i]==shipId){
            return false;
        }
    }

    //update the grid with the ship's symbol
    char symbol = m_game.shipSymbol(shipId);
    if(dir == HORIZONTAL){
        for(int i=0; i<length; i++){
            m_grid[topOrLeft.r][topOrLeft.c + i] = symbol;
        }
    }
    if(dir == VERTICAL){
        for(int i=0; i<length; i++){
            m_grid[topOrLeft.r+i][topOrLeft.c] = symbol;
        }
    }
    
    //add the ship id to the vector
    m_shipIds.push_back(shipId);
       
    return true;
}

bool BoardImpl::unplaceShip(Point topOrLeft, int shipId, Direction dir)
{
    //check if shipId is invalid
    if(shipId<0 || shipId > m_game.nShips()-1){
        return false;
    }
    
    //check: "The board does not contain the entire ship at the indicated locations."
    
    char symbol = m_game.shipSymbol(shipId);
    int length = m_game.shipLength(shipId);
    if(dir == HORIZONTAL){
        Point right(topOrLeft.r, (topOrLeft.c + length - 1));
        if(!m_game.isValid(topOrLeft) || !m_game.isValid(right)){
            return false;
        } // double check that the points are valid
        
        for(int i=0; i<length; i++){
            if(m_grid[topOrLeft.r][topOrLeft.c + i] != symbol){
                return false;
            }
        }
    }
    if(dir == VERTICAL){
        Point bottom((topOrLeft.r + length - 1), topOrLeft.c);
        if(!m_game.isValid(topOrLeft) || !m_game.isValid(bottom)){
            return false;
        } //double check that the points are valid
        
        for(int i=0; i<length; i++){
            if(m_grid[topOrLeft.r+i][topOrLeft.c] != symbol){
                return false;
            }
        }
    }
    
    //unplace the ship, update the grid
    if(dir == HORIZONTAL){
        for(int i=0; i<length; i++){
            m_grid[topOrLeft.r][topOrLeft.c + i] = '.';
        }
    }
    if(dir == VERTICAL){
        for(int i=0; i<length; i++){
            m_grid[topOrLeft.r+i][topOrLeft.c] = '.';
        }
    }
    //erase from the vector
    vector<int>::iterator x = m_shipIds.begin();
    for(int i = 0; i < m_shipIds.size() ;i++){
        if(m_shipIds[i]==shipId){
            m_shipIds.erase(x);
            break;
        }
        x++;
    }
    return true; // This compiles, but may not be correct
}

void BoardImpl::display(bool shotsOnly) const
{
    cout<<"  ";
    for(int i=0; i<m_game.cols();i++){
        cout<<i;
    }
    cout<<endl;
    
    for(int r=0; r<m_game.rows(); r++){
        for(int c=-1;c<m_game.cols(); c++){
            if (c==-1){
                cout<<r<<" ";
            }
            else if(shotsOnly && m_grid[r][c]!='X' && m_grid[r][c]!='o' && m_grid[r][c]!='.'){//has to be a ship symbol
                cout<<'.';
            }
            else{
                cout<<m_grid[r][c]; //rely on attack to record the changes to the grid
            }
        }
        cout<<endl;
    }
}

bool BoardImpl::attack(Point p, bool& shotHit, bool& shipDestroyed, int& shipId)
{
    shipDestroyed = false;
    shotHit = false; //double check?
    if(m_game.isValid(p)==false){
        return false;
    }
    if(m_grid[p.r][p.c] == 'X' || m_grid[p.r][p.c] == 'o'){
        return false;
    }

    if(m_grid[p.r][p.c] != 'X' && m_grid[p.r][p.c] != '.' && m_grid[p.r][p.c] != 'o'){
        m_grid[p.r][p.c] = 'X';
        shotHit = true;
        //update shipDestroyed if needed
        //for each ship id in shipIDs, check if its symbol is still on the board
        vector<int>::iterator x = m_shipIds.begin();
        for(int i = 0; i < m_shipIds.size() ;i++){
            char symbol = m_game.shipSymbol(m_shipIds[i]);
            bool symbolFound = false;
            for(int r=0; r<m_game.rows();r++){
                for(int c=0;c<m_game.cols();c++){
                    if(m_grid[r][c]==symbol){
                        symbolFound = true;
                    }
                }
            }
            if(symbolFound == false){
                shipDestroyed = true;
                shipId = m_shipIds[i];
                m_shipIds.erase(x);
                break;
            }
            x++;
        }
    }

    else if(m_grid[p.r][p.c]=='.'){
        m_grid[p.r][p.c] = 'o';
        shotHit = false;
    }
    
    
    return true; // This compiles, but may not be correct
}

bool BoardImpl::allShipsDestroyed() const
{ //is this right?
    if(m_shipIds.empty()){
        return true;
    }
    return false; // This compiles, but may not be correct
}

//******************** Board functions ********************************

// These functions simply delegate to BoardImpl's functions.
// You probably don't want to change any of this code.

Board::Board(const Game& g)
{
    m_impl = new BoardImpl(g);
}

Board::~Board()
{
    delete m_impl;
}

void Board::clear()
{
    m_impl->clear();
}

void Board::block()
{
    return m_impl->block();
}

void Board::unblock()
{
    return m_impl->unblock();
}

bool Board::placeShip(Point topOrLeft, int shipId, Direction dir)
{
    return m_impl->placeShip(topOrLeft, shipId, dir);
}

bool Board::unplaceShip(Point topOrLeft, int shipId, Direction dir)
{
    return m_impl->unplaceShip(topOrLeft, shipId, dir);
}

void Board::display(bool shotsOnly) const
{
    m_impl->display(shotsOnly);
}

bool Board::attack(Point p, bool& shotHit, bool& shipDestroyed, int& shipId)
{
    return m_impl->attack(p, shotHit, shipDestroyed, shipId);
}

bool Board::allShipsDestroyed() const
{
    return m_impl->allShipsDestroyed();
}
